from django.shortcuts import render
from patient.models import *
def userdata(request):
	msg=""
	data=""
	if request.method=="POST":
		sid=request.POST["sid"]
		UserDetails.objects.filter(id=sid).delete()
		msg="Record Deleted Successfully"
	data=UserDetails.objects.all()
	return render(request,"userdata.html",{"data":data,"msg":msg})
def register(request):
	msg=""
	data=""
	if request.method=="POST":
		sd=UserDetails()
		sd.username=request.POST["username"]
		sd.firstname=request.POST["firstname"]
		sd.lastname=request.POST["lastname"]
		sd.emailaddress=request.POST["emailaddress"]
		sd.password=request.POST["password"]
		sd.confirmpassword=request.POST["confirmpassword"]
		

		sd.save()
		msg="Registered successfully"
	return render(request,"register.html",{"msg":msg})
def searchuserdata(request):
	data=""
	msg=""
	if request.method=="POST":
		searchby=int(request.POST["searchby"])
		value=request.POST["value"].upper()
		if searchby==1:
			data=UserDetails.objects.filter(id=value)
		elif searchby==2:
			data=UserDetails.objects.filter(username__contains=value)
		elif searchby==3:
			data=StudentDetails.objects.filter(firstname=value)
		elif searchby==4:
			data=StudentDetails.objects.filter(lastname=value)
	return render(request,"searchuserdata.html",{"data":data})
def login(request):
	msg=""
	if request.method=="POST":
		p_username=request.POST["username"]
		p_password=request.POST["password"]
		if UserDetails.objects.filter(username=p_username,password=p_password).exists():
			request.session ["username"] = p_username
			return render(request,"userhome.html")
		else:
		  	msg="invalid user name or password"
	return render(request,"userlogin.html",{"msg":msg})
def userhome(request):
	return render(request,"userhome.html")
def userlogin(request):
	msg=""
	if request.method=="POST":
		p_username=request.POST["username"]
		p_password=request.POST["password"]
		if UserDetails.objects.filter(username=p_username,password=p_password).exists():
			request.session ["username"] = p_username
			return render(request,"userhome.html")
		else:
		  	msg="invalid user name or password"
	return render(request,"userlogin.html",{"msg":msg})
def changepassword(request):
	msg=""
	if request.method=="POST":
		currentpassword=request.POST["currentpassword"]
		newpassword=request.POST["newpassword"]
		confirmnewpassword=request.POST["confirmnewpassword"]
		p_username=request.session["username"]
		if confirmnewpassword==confirmnewpassword:
			if UserDetails.objects.filter(username=p_username,password=currentpassword).exists():
				UserDetails.objects.filter(username=p_username,password=currentpassword).update(password=newpassword)
				msg="password updated successfully"
			else:
				msg="current password is invalid"
		else:
			msg="new password and confirm new password must be same"
	return render(request,"changepassword.html",{"msg":msg})
def onlineblog(request):
	msg=""
	
	if request.method=="POST":
		sd=onlineblog()
		sd.title=request.POST["title"]
		sd.slug=request.POST["slug"]
		sd.content=request.POST["content"]
		sd.image=request.POST["image"]
		sd.save()
		msg="Saved Successfully"
	
	return render(request,"onlineblog.html",{"msg":msg})	