from django.db import models
class UserDetails(models.Model):
	username=models.CharField(max_length=100,default="")
	firstname=models.CharField(max_length=15,default="")
	lastname=models.CharField(max_length=15,default="")
	emailaddress=models.CharField(max_length=100,default="")
	password=models.CharField(max_length=20,default="")
	confirmpassword=models.CharField(max_length=20,default="")
class onlineblog(models.Model):
	title=models.CharField(max_length=100,default="")
	slug=models.CharField(max_length=15,default="")
	content=models.CharField(max_length=200,default="")
	image=models.CharField(max_length=50,default="")
	
	
